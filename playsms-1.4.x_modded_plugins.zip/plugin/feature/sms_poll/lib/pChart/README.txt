Source : https://github.com/bozhinov/pChart2.0-for-PHP7
Commit : a09f1a06fcc7b5736a5a243bf8a088c0fb27954c
Author : Momchil Bozhinov <momchil@bojinov.info>
Date   : Thu Feb 21 09:38:13 2019 +0200
