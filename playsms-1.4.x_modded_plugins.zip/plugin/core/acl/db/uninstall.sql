--
-- Table structure for table `playsms_tblACL`
--

DROP TABLE IF EXISTS `playsms_tblACL`;

ALTER TABLE `playsms_tblUser` DROP `acl_id`;
