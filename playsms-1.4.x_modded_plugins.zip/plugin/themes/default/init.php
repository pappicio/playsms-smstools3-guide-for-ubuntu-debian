<?php
defined('_SECURE_') or die('Forbidden');

include $core_config['apps_path']['themes']."/".core_themes_get()."/config.php";
include $core_config['apps_path']['themes']."/".core_themes_get()."/fn.php";
