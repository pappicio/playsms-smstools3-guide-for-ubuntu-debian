<?php
$plugin_config['en_US']['title'] = 'English (United States)';
