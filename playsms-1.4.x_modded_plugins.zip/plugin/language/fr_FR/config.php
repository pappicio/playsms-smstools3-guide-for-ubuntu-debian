<?php
$plugin_config['fr_FR']['title'] = 'French (France)';
