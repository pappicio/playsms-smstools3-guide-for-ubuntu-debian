<?php
defined('_SECURE_') or die('Forbidden');

// captcha options
$auth_captcha_length = 6;
$auth_captcha_seed = 'efhkmnpqrwxyz98765432';
$auth_captcha_width = 150;
$auth_captcha_height = 40;

// enable/disable captcha
$auth_captcha_form_login = FALSE;
$auth_captcha_form_forgot = FALSE;
$auth_captcha_form_register = FALSE;

