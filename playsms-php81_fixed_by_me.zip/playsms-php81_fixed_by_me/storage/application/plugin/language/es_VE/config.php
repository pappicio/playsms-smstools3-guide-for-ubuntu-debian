<?php
$plugin_config['es_VE']['title'] = 'Spanish (Venezuela)';
