-- 1.4.2


-- version
UPDATE `playsms_tblRegistry` SET `registry_value` = '1.4.2' WHERE `registry_group` = 'core' AND `registry_family` = 'config' AND `registry_key` = 'playsms_version' ;
